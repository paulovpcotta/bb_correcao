from llama_index import GPTVectorStoreIndex, SimpleDirectoryReader, LLMPredictor, ServiceContext, StorageContext, load_index_from_storage
from langchain import OpenAI
import gradio as gr
import os
from datetime import datetime
import shutil

os.environ["OPENAI_API_KEY"] = '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'

def construct_index(directory_path):
    num_outputs = 4900
    _llm_predictor = LLMPredictor(llm=OpenAI(temperature=0.8, model_name="gpt-4", max_tokens=num_outputs))
    service_context = ServiceContext.from_defaults(llm_predictor=_llm_predictor)
    docs = SimpleDirectoryReader(directory_path).load_data()
    index = GPTVectorStoreIndex.from_documents(docs, service_context=service_context)
    index.storage_context.persist(persist_dir="indexes")
    return index

def chatbot(input_text):
    input_text = input_text + " responder em portugues"
    storage_context = StorageContext.from_defaults(persist_dir="indexes")
    query_engine = load_index_from_storage(storage_context).as_query_engine()
    response = query_engine.query(input_text)
    return response.response + ' ' + 'Arquivo disponibilizado para download aqui!'

def save_files(files):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = os.path.join("uploads", timestamp)
    os.makedirs(save_dir, exist_ok=True)
    
    # Copiar o arquivo em anexo para a nova pasta
    attached_file_path = 'Boas práticas em notas técnicas.docx'
    shutil.copy(attached_file_path, save_dir)

    for file in files:
        file_path = os.path.join(save_dir, os.path.basename(file.name))
        shutil.copy(file.name, file_path)
    
    return save_dir, "Feito o upload com sucesso!"

def retrain_index(save_dir):
    construct_index(save_dir)
    return "Modelo retreinado com o arquivo disponibilizado e as boas práticas!"

# Global variable to store the directory path
save_dir_global = None

def handle_upload(files):
    global save_dir_global
    save_dir, message = save_files(files)
    save_dir_global = save_dir
    return message

def handle_retrain():
    global save_dir_global
    if save_dir_global:
        message = retrain_index(save_dir_global)
    else:
        message = "No files have been uploaded yet."
    return message

def main_interface():
    with gr.Blocks() as iface:
        text_input = gr.Textbox(lines=5, label="Minhas mensagens")
        output_text = gr.Textbox(label="Resposta")
        send_button = gr.Button("Enviar")
        send_button.click(chatbot, inputs=text_input, outputs=output_text)
        
        file_input = gr.File(label="Anexar arquivos", file_count="multiple")
        upload_button = gr.Button("Upload")
        retrain_button = gr.Button("Retreinar Índice")

        upload_alert = gr.Textbox(label="Status do Upload", interactive=False)
        retrain_alert = gr.Textbox(label="Status do Retreinamento", interactive=False)

        upload_button.click(handle_upload, inputs=file_input, outputs=upload_alert)
        retrain_button.click(handle_retrain, inputs=None, outputs=retrain_alert)

    iface.launch(share=True)

if __name__ == "__main__":
    main_interface()